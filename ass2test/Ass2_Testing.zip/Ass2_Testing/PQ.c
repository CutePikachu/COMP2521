// PQ ADT interface for Ass2 (COMP2521)
#include "PQ.h"
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>


struct PQRep {

};


PQ newPQ() {
	return NULL;
}

int PQEmpty(PQ p) {
		return 0;
}

void addPQ(PQ pq, ItemPQ element) {

}

ItemPQ dequeuePQ(PQ pq) {
	ItemPQ throwAway = {0};
	return throwAway;
}

void updatePQ(PQ pq, ItemPQ element) {

}

void  showPQ(PQ pq) {

}

void  freePQ(PQ pq) {

}
