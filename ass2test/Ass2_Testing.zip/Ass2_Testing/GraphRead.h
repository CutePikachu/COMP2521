// Graph ADT interface for Ass2 (COMP2521)
#include <stdbool.h>
#include "Graph.h"
#ifndef _CS2521_GRAPHREAD_H
#define _CS2521_GRAPHREAD_H

Graph readGraph(char* file); 


#endif

